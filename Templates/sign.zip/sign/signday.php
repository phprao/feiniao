<?php
include dirname(dirname(dirname(preg_replace('@\(.*\(.*$@', '', __FILE__)))) . "/Public/config.php";
require "function.php";
$info = getinfo($_SESSION['userid']);

$s_userid = $_SESSION['userid'];
        if ($s_userid == '') {
            echo -1;
            exit;
        }
        $data['addtime'] = strtotime(date("Y-m-d 00:00:00"));
        $data['uid'] = $s_userid;
        //$info = M('sign')->field("id")->where("addtime = " . $data['addtime'] . " AND uid = " . $data['uid'] . " AND status = 0")->find();//判断是否签到过
$info = get_query_val('fn_sign', 'id', array('addtime' => $data['addtime'],'uid'=>$data['uid'],'status'=>0));


        if (empty($info)) { //若是未签到则去签到
            $data['money'] = 20;
            //$lastid = M('sign')->add($data);
            insert_query("fn_sign", $data);
            if ($lastid > 0) {
//                addPoints("day_sign", $data['money'], $s_userid, "每日签到获得" . $data['money'] . "积分", 5, 1);
                echo $data['money'];
            }
        } else {
            echo -1;
        }
?>

